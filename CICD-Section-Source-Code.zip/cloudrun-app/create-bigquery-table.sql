create schema test_schema;

create or replace table `udemy-mlops-395416.test_schema.us_states`
(
name STRING,
post_abbr STRING
)