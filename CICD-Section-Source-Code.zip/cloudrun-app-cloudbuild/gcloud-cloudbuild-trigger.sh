# Command to run the build using cloudbuild.yaml
gcloud builds submit --region us-central1