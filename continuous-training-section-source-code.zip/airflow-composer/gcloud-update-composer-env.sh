gcloud composer environments update mlops-airflow  \
--location us-central1 \
--update-pypi-packages-from-file requirements.txt