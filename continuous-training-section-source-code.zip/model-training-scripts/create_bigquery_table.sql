create schema ml_ops;

CREATE TABLE `udemy-mlops.ml_ops.bank_campaign_model_metrics` (
  algo_name STRING,
  training_time TIMESTAMP,
  model_metrics STRING
)